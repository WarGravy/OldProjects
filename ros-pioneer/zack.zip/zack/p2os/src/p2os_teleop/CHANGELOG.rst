^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package p2os_teleop
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.9 (2013-08-18)
------------------
* Updated version
* 1.0.7
* Updated changelogs

1.0.7 (2013-08-18)
------------------

* Updated to match hmt-git.com repository

1.0.5 (2013-07-23)
------------------
* Cleaned up for release
* Removed manifest and mainpage

* Updated to match hmt-git.com

* Updated to hmt-git.com repo

1.0.1 (2013-07-22)
------------------
* Updating to match hmt-git.com repo
* Fixed cmake file
* Removed line
* Updated p2os_teleop package to use catkin_make
* added the code
