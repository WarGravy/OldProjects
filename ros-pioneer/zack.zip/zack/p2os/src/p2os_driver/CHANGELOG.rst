^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package p2os_driver
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.9 (2013-08-18)
------------------
* Updated version
* 1.0.7
* Updated changelogs

1.0.7 (2013-08-18)
------------------

* Updated to match hmt-git.com repository

1.0.5 (2013-07-23)
------------------

* Syncing github with hmt-git.com repository

1.0.1 (2013-07-22)
------------------
* Updating to match hmt-git.com repo
* Added forgotten dependencies
* Added package dependencies
* Updated C++ Code
* Updated package.xml
* Updated CMakeLists.txt
* Updated CMakeLists.txt
* Added message header files
* Remapped the files to the right headers
* cleaned up include directory
* Updated the main driver to use catkin
* Added covariance to Odometry msg.
* Modified the CMakeLists.txt file.
* added the code
