^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package p2os_launch
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.9 (2013-08-18)
------------------
* Updated version
* 1.0.7
* Updated changelogs
* Updated the launch files

1.0.7 (2013-08-18)
------------------
* Updated the launch files

* Updated to match hmt-git.com repository

1.0.5 (2013-07-23)
------------------

* Added new navigation files
* Added new launch files
* Updated to match hmt-git.com

* Updated to hmt-git.com repo

1.0.1 (2013-07-22)
------------------
* Updating to match hmt-git.com repo
* Removed a line
* Updated p2os_launch for catkin
* Removed build directory.
* Added a new launch file
* added the code
