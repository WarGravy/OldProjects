//Class written by 
//INCLUDE FILES
  #include <iostream>
  #include "adt4.h"
  using namespace std;

