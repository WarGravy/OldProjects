//Program written and designed by Zachary Carlson and Jay Thom
// HEADER FILES
#include <iostream>
#include "adt1.h"
#include "adt2.h"
#include "adt3.h"
#include "adt4.h"
#include "adt5.h"
#include "adt6.h"
#include "adt7.h"
using namespace std;

int main(){
  //initialize variables
	
  return 0;
}

