//Class written by 
//INCLUDE FILES
  #include <iostream>
  #include "adt2.h"

