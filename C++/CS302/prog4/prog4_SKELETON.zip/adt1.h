//Class written by 
using namespace std;

class linkedListSorted{
public:
private:
};
