//Class written by 
//INCLUDE FILES
  #include <iostream>
  #include "adt5.h"
  using namespace std;

