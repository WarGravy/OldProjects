//Class written by 
//INCLUDE FILES
  #include <iostream>
  #include "adt7.h"
  using namespace std;

