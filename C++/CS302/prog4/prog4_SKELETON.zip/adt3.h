//Class written by 
using namespace std;

class bsTreeRecursive{
public:
private:
};
