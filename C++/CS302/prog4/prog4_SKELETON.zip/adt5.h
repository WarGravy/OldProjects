//Class written by 
using namespace std;

class arrayListSorted{
public:
private:
};
