//Class written by 
//INCLUDE FILES
  #include <iostream>
  #include "adt6.h"
  using namespace std;

