//Program written and designed by Zachary Carlson and Jay Thom
// HEADER FILES
#include <iostream>
#include <fstream>
#include "intervalTree.h"
using namespace std;

/*GLOBAL VARIABLES<these are all that need to be changed to determine how the program runs*/
//the name of the input file
const char fileName[] = "input.txt";
//the name of the output file
const char fileName2[] = "output.txt";
//number of intervals in the input file
const int numberOfIntervals = 10;

//MAIN PROGRAM
int main(){
  //initialize variables
  int index = 0;
  int index2;
  long low, high;
  bool menu = true;
  char menuI;
  int temp;
    //initialize interval tree
    intervalTree tree;
    //initialize fstream related
    ofstream fout;
    fout.clear();
    fout.open(fileName2);
    fout.clear();
    ifstream fin;
    fin.clear();
    fin.open(fileName);
    if(fin.good()){
        cout << "The file: " << fileName << " was opened correctly." << endl;
        fout << "The file: " << fileName << " was opened correctly." << endl;
    }
    /*initialize input array(2d array) row determines the interval, col determines whether it is low, or high*/  
    long input[2][numberOfIntervals];
    while(fin.good() && index < numberOfIntervals){
    fin >> input[0][index];
    fin >> input[1][index];
    cout<<"Input List item "<<index<<": "<<input[0][index]<<"-"<<input[1][index]<<endl;
    fout<<"Input List item "<<index<<": "<<input[0][index]<<"-"<<input[1][index]<<endl;
    index++;
    }
    fin.close();
   //insert all values into interval tree
   for(index2 =0; index2 < index; index2++){
        tree.rbInsert(input[0][index2], input[1][index2], fout);
	}
  //run menu system
  while(menu){
  cout << "Program 5: Interval Tree"<<endl<<endl<<"(1)Print Tree"<<endl<<"(2)Search Tree"<<endl<<"(3)Delete Interval"<<endl<<"(4)Quit"<<endl<<endl;
  fout << "Program 5: Interval Tree"<<endl<<endl<<"(1)Print Tree"<<endl<<"(2)Search Tree"<<endl<<"(3)Delete Interval"<<endl<<"(4)Quit"<<endl<<endl;
  cin >> menuI;
  fout << menuI << endl;
    switch(menuI){ 
    //print
    case '1':
    tree.print(fout);
    break;
    //search
    case '2':
    cout << "Enter the low value for the interval search: " <<endl;
    fout << "Enter the low value for the interval search: " <<endl;
    cin >> low;
    fout << low;
    cout << "Enter the high value for the interval search: " <<endl;
    fout << "Enter the high value for the interval search: " <<endl;
    cin >> high;
    fout << high;
    tree.search(low, high, fout);
    break;
    //delete
    case '3':
    cout << "Enter the low value for the interval to delete: " <<endl;
    fout << "Enter the low value for the interval to delete: " <<endl;
    cin >> low;
    fout << low;
    cout << "Enter the high value for the interval to delete: " <<endl;
    fout << "Enter the high value for the interval to delete: " <<endl;
    cin >> high;
    fout << high;
    temp = tree.find(low, high, fout);
    if(temp == low){
    tree.rbDelete();
    }
    break;
    //quit
    case '4':
    menu=false;
    break;
  
    default:
    cout << "Please input the number associated with the menu option on the screen."<<endl;
    fout << "Please input the number associated with the menu option on the screen."<<endl;
    break;
    }
  }
  //end 
  fout.close();
  return 0;
}

