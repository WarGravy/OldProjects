//Program written and designed by Zachary Carlson and Jay Thom
// HEADER FILES
#include <iostream>
#include <fstream>
#include "intervalTree.h"
using namespace std;

/*GLOBAL VARIABLES<these are all that need to be changed to determine how the program runs*/


//MAIN PROGRAM
int main(){
  //initialize variables
    
  //end 
  return 0;
}

