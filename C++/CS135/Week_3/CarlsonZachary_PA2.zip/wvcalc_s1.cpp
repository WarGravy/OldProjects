/*//////////////////////////////////////////////////////////////////////////
  
    Program:             wvcalc.cpp
    Author:              <Zachary Carlson>
    Update By:           n/a
    Description:         Program calculates Y position in a Wave.

    Program Written:     02/12/2012
    Most Recent Update:  02/12/2012 - 4:10 p.m.
    Date Due for Review: 02/14/2012

/////////////////////////////////////////////////////////////////////////*/

// Header Files

   #include "formatted_cmdline_io_v06.h"	// for console I/O

   using namespace std;

// Global Constant Definitions

   // none

// Global Function Prototypes

    // none

// Main Program Definition
int main()
   {
    // initialize program

    // input Data

    // calculate Y position

    // output Data

    // end program

       // return zero
       return 0;
   }

// Supporting function implementations

    // none



