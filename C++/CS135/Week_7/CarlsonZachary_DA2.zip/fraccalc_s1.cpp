
/*//////////////////////////////////////////////////////////////////////////
  
    Fraction Calculator

    Name: Zachary Carlson    
    Code Written:        03/7/2012
    Most Recent Update:  03/9/2012- 11:27 a.m.
    Date Due for Review: 03/12/2012

/////////////////////////////////////////////////////////////////////////*/

//Include Files
#include <cmath>
#include "digits_v01.h"
using namespace std;

//Global Constants
  //none

//Function Prototypes
  //none

//Main Program
int main()
  {
   //initialize program///////////////////////////////////////////////////

   ////////input and output///////////////////////////////////////////////

   //end program//////////////////////////////////////////////////////////

     //stub
     return 0;
  }
//Function Implementations
  //none
