/*//////////////////////////////////////////////////////////////////////////
  
    Fraction Calculator

    Name: Zachary Carlson    
    Code Written:        03/7/2012
    Most Recent Update:  03/12/2012- 7:31 p.m.
    Date Due for Review: 03/12/2012

/////////////////////////////////////////////////////////////////////////*/

//Include Files
#include <cmath>
#include "digits_v01.h"
using namespace std;

//Global Constants
  //none

//Function Prototypes
  //none

//Main Program
int main()
  {
   //initialize program///////////////////////////////////////////////////
     //initialize local variables
   
     //start curses

     //clear screen

     //displayInputScreen(title included)

   ////////input and output///////////////////////////////////////////////
   //Prompt for numOne

     //if (parameters for numOne)

     //{ Starting bracket for if (numOne)

     //Prompt for denTwo

        //if(parameters for denTwo)

        //{ starting bracket for if (denTwo)

        //Prompt for operator

          //if(parameters for operator)

          //{ starting bracket for if (oper)

          //Prompt for numTwo

             //if (parameters for second numerator)

             //{ starting bracket for if (numTwo)

             //Prompt for denTwo

               //if(parameters for second denominator)

               //{ starting bracket for if (denTwo)

                 /* Calculate answer
                 the function will output the answer as well
                 numOne, denTwo, oper, numTwo, denTwo
                 */

               //} ending bracket for if(denTwo)

               //else(ending else for second denominator)

               //{ else bracket start denTwo

               //submit error message

               //} else bracket end denTwo      
  
             //} end bracket for if (num Two)

             //else(ending else for second numerator)

             //{ else bracket start numTwo

             //submit error message

             //} else bracket end numTwo

          //} ending bracket for if (oper)

          //else(ending else for parameter operator)

          //{ else bracket start oper

          //submit error message

          //} else bracket end oper

        //} ending bracket for if (denOne)

        //else(ending else for parameter denOne)

        //{ else bracket start denOne

        //submit error message

        //} else bracket end denOne

     //} ending bracket for if (numOne)

     //else(ending else for parameter numOne)

     //{ else bracket start numOne

     //submit error message

     //} else bracket end numOne

 
   //end program//////////////////////////////////////////////////////////

     // print "Press any key to end program . . ."

     //wait for input(-7)

     //end curses

     //stub
     return 0;
  }
//Function Implementations
  //none
