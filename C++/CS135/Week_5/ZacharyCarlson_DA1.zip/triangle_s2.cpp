/*//////////////////////////////////////////////////////////////////////////
  
    Triangle Analysis Program

    Name: Zachary Carlson    
    Code Written:        02/27/2012
    Most Recent Update:  02/27/2012- 9:28 p.m.
    Date Due for Review: 02/28/2012

/////////////////////////////////////////////////////////////////////////*/

//  Header Files  
#include "formatted_console_io_v16.h"
#include <cmath>

using namespace std;

//Global Constants
         //none

//Function Prototypes
         //none

//Main Program

int main()
    {
    //initialize program

       //initialize variables

       //start curses

       //clear screen for outside background
       
       //create data input screen

    //input Data

       //prompt user for side 1

       //prompt user for side 2

       //prompt user for side 3

     //Output Results
    
       // display error or display results
        // if user input sides 1, 2, and 3 are in range, display everything/////

        //start if {

           //output triangle sides and title
       
          //find what type of triangle
             // use if statements to determine if Equilateral, Isos, or Scalene
               //if equilateral 

               //else if isos 
            
               //else scalene                   
           
          //find angle type
            // use if statements to determine if Obtuse, Right, or Acute
              //if right 

              //else if Acute 

              //else Obtuse 

        //end if }
                
      //else if sides are not in parameters display error//////////////////////

         //print error message

      //move "press any key to continue . . ." aka cursor to bottom right corner


           
    //End Program
          //system pause

          // function: endCurses

          //return to zero
       return 0;
    }

//Function Implementations

          //None
