/*//////////////////////////////////////////////////////////////////////////
  
    Triangle Analysis Program

    Name: Zachary Carlson    
    Code Written:        02/27/2012
    Most Recent Update:  02/27/2012- 9:15 p.m.
    Date Due for Review: 02/28/2012

/////////////////////////////////////////////////////////////////////////*/

//  Header Files  
#include "formatted_console_io_v16.h"
#include <cmath>

using namespace std;

//Global Constants
         //none

//Function Prototypes
         //none

//Main Program

int main()
    {
    //initialize program

    //input Data

    //Output Results
    
    //End Program

       //return to zero
       return 0;
    }

//Function Implementations
          //None
