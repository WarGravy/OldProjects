//////////////////////////include files//////////////////////////

#include <iostream>
#include <fstream>
#include "formatted_console_io_v16.h"
using namespace std;

//////////////////////////global constants///////////////////////


/////////////////////function prototypes ////////////////////////


////////////////////////main program/////////////////////////////
int main()
  {
  //initialize function / variables
    

    //star curses
    
    //display splash intro

    // run program

    //display menu
    
        //switch
   
              //case R or r
                  //rules

              //break

        
              //case D or d
                  //difficulty

              //break

       
              //case p or P
                  //play game
        
              //break

        
              //case t or T
                  //top scores
        
              //break

              
              //case q or Q
                  //quit screen
        
              //break


       // until user chooses quit


    // shut down program


    // wait for user input


       // shut down curses

  
       // return success

  }

//////////// Function Implementation ////////////////////////

