//////////////////////////include files//////////////////////////

#include <iostream>
#include <fstream>
#include "formatted_console_io_v16.h"
using namespace std;

//////////////////////////global constants///////////////////////


/////////////////////function prototypes ////////////////////////


////////////////////////main program/////////////////////////////
int main()
  {
  //initialize function / variables
    

    //star curses
    
    //display splash intro

    // run program

    //display menu
    
        //switch
   

    // until user chooses quit


    // shut down program


    // wait for user input


       // shut down curses

  
       // return success

  }

//////////// Function Implementation ////////////////////////

