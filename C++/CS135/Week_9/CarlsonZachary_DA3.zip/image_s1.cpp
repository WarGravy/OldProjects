/*
Name: Zachary Carlson
Latest Update: 04/01/2012 - 4:45pm

Program Name: Design Assignment 3/ Program Assignment 6: image
*/

//include files
#include <iostream>
#include <fstream>
#include "formatted_console_io_v16.h"
using namespace std;

//global constants

  //none

//function prototypes

  //none

//main program
int main()
  {
  //initialize variables and main function

  //input

           //output image data

  //end program

  //stub
  return 0;
  }

//function implementations

  //none
