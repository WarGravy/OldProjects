/*
Name: Zachary Carlson
Latest Update: 04/01/2012 - 5:18 pm

Program Name: Design Assignment 3/ Program Assignment 6: image
*/

//include files
#include <iostream>
#include <fstream>
#include "formatted_console_io_v16.h"
using namespace std;

//global constants

  //none

//function prototypes

  //none

//main program
int main()
  {
  //initialize variables and main function
    //declare variables

    //start curses
     
    //display screen
      
  //input

    //prompt for filename
         
      //clear fstream and open file
      
      //if .good
      
       //{
       
        //prompt for x offset
             
        //prompt for y offset
          
           //output image data

             //print the character in the correct color
               
           //close file
           
         //}
         
      //else
      
       //{    
       
        //display error message
         
            //end program
              // print "Press any key to end program . . ."
               
              //wait for input
               
              //end curses
              
              //return 0
              
       //}
      
  //end program
    // print "Press any key to end program . . ."
    
    //wait for input
      
    //end curses
      
  //stub
  return 0;
  }

//function implementations

  //none
