//Class written by 
//INCLUDE FILES
  #include <iostream>
  #include "adt3.h"

