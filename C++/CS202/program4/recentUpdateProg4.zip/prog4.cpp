//Program written and designed by Zachary Carlson and Jay Thom
// HEADER FILES
#include <iostream>
#include "adt1.h"
#include "adt2.h"
#include "adt3.h"
#include "adt4.h"
#include "adt5.h"
#include "adt6.h"
#include "adt7.h"
using namespace std;

int main(){
  //initialize variables
    /*generate  2^32 random numbers between 1  and 1,000,000 loaded into an array(INPUT LIST)*/
    /*generate  2^32 random numbers between 1  and 1,000,000 loaded into an array(SEARCH LIST)*/
    /*generate array(DELETE LIST)*/

  //Loop through all ADTs

    //INSERTION PHASE
      //output start time 
      //insert all randomly generated numbers into adt
      //output end time
      //output number of swaps
      //output number of comparisons

    //SEARCH PHASE
      //output start time
      //search for all numbers in the search list
      //output end time
      //output number of swaps
      //output number of comparisons

    //DELETION PHASE
      //output start time
      //delete all numbers in the delete list
      //output end time
      //output number of swaps
      //output number of comparisons

  //end 
  return 0;
}

