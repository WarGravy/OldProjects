//Class written by 
using namespace std;
class nodeSort
   {
    friend class linkedListSorted;
    public:
    nodeSort();
    ~nodeSort();
    private:
    int value;
    nodeSort* next;
   };

class linkedListSorted{
   public:
  linkedListSorted();
  linkedListSorted(const linkedListSorted&);
  ~linkedListSorted();
  bool goToBeginning();
  bool goToEnd();
  bool find(int, int&, int& comparisons);
  bool goToPrior();
  bool insert(int, int&, int& comparisons);
  void remove(int, int&, int& comparisons);
  bool replace(int);
  int getCursor();
  bool empty();
  bool full();
  void clear();
  void print();
  private:
  bool insertAfter(int);
  bool insertBefore(int);
  nodeSort* head;
  nodeSort* cursor;
};
