//Class written by 
using namespace std;

class arrayListSorted{
  public:
  arrayListSorted(int);
  ~arrayListSorted();
  bool insert(int, int& swaps, int& comparisons);
  void clear();
  bool search(int, int& swaps, int& comparisons);
  bool getint(int&);
  void deleteInt(int, int& swaps, int& comparisons);
  void print();
  private:
  int* list;
  int cursor; 
  int rear;
  int size;
};
