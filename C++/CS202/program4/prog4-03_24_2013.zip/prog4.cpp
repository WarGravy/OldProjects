//Program written and designed by Zachary Carlson and Jay Thom
// HEADER FILES
#include <iostream>
#include "adt1.h"
#include "adt2.h"
#include "adt3.h"
//#include "adt4.h" linking it via adt4
#include "adt5.h"
#include "adt6.h"
#include "adt7.h"
//included for random number generating
#include <cstdlib>
//include for time (www.cplusplus.com/reference/ctime/clock/)
#include <time.h>
using namespace std;

//GLOBAL VARIABLES
/*used for generating numbers for input, search, and delete list(1,000 / 10,000 / 100,000 / 1,000,000)*/
const int MAX_INTEGERS = 1000;
//this will need to be changed to 2^32 or 4,294,967,296(NEEDS A 6)
const long BOUNDS = 1000;
const int NUM_ADTS = 5;


//MAIN PROGRAM
int main(){
  //initialize variables
     int tempNum;
     bool found;
     srand( time(NULL));
     long randomNumb;
     long input[MAX_INTEGERS];
     long search[MAX_INTEGERS];
     long deleteList[MAX_INTEGERS];
     //time/////////////////////////

     //index variables
     int gen, i, j, k, x, y, index;
     int swaps=0;
     int comparisons=0;
     //initialize ADTs
     linkedListSorted adt1;
     linkedListUNSorted adt2;
     iTreeType adt3;
     TreeType adt4;
     arrayListSorted adt5(MAX_INTEGERS);
     //arrayListUNSorted adt6(MAX_INTEGERS);
    /*generate  2^32 random numbers between 1  and 1,000,000 loaded into an array(INPUT LIST)*/
     for(gen = 0; gen < MAX_INTEGERS; gen++){
     randomNumb = rand() % BOUNDS;
     input[gen] = randomNumb;
     }
    /*generate  2^32 random numbers between 1  and 1,000,000 loaded into an array(SEARCH LIST)*/
     for(gen = 0; gen < MAX_INTEGERS; gen++){
     randomNumb = rand() % BOUNDS;
     search[gen] = randomNumb;
     }
    /*generate array(DELETE LIST)*/
    i=j=k=0;
    while(i < MAX_INTEGERS){
       /*find index where value of input[i] is equal to search list or run through entire list*/
       for(j=0; input[i]!=search[j] && j < MAX_INTEGERS;j++){
       }
       //check if the index is true
       if(input[i] == search[j]){
         deleteList[k]=input[i];
         k++;
       }
     i++;
    }
  //cout << k << "AND" << i <<endl;//See how many were in both lists

  //Loop through all ADTs
  for(index = 0; index < NUM_ADTS; index++){
    //initialize swaps and comparisons
    swaps=0;
    comparisons=0;
    //INSERTION PHASE
      //insert all randomly generated numbers into adt
         //adt1
         if(index == 0){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt1.insert(input[x]);
      		}
	 }
         //adt2
         else if(index == 1){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt2.insert(input[x]);
      		}
	 }
         //adt3
         else if(index == 2){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt3.PutItem(input[x]);
      		}
	 }
         //adt4
         else if(index == 3){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt4.PutItem(input[x]);
      		}
	 }
         else if(index == 4){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt5.insert(input[x]);
      		}
	 }
         /*
         else if(index == 5){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt6.insertAtEnd(input[x]);
      		}
	 }*/
      //output end time
      //cout << clock() << endl;

      //output number of swaps
      cout << "SWAPS for Insertion Phase: "<< swaps << endl;
      //output number of comparisons
      cout << "COMPARISONS for Insertion Phase: "<<comparisons << endl<<endl;

    //initialize swaps and comparisons
    swaps=0;
    comparisons=0;

    //SEARCH PHASE
        //adt1
         if(index == 0){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt1.find(search[x]);
      		}
	 }
         //adt2
         else if(index == 1){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt2.find(search[x]);
      		}
	 }
         //adt3
         else if(index == 2){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		tempNum = adt3.GetItem(search[x], found);
      		}
	 }
         //adt4
         else if(index == 3){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		tempNum = adt4.GetItem(search[x], found);
      		}
	 }
         else if(index == 4){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt5.search(search[x]);
      		}
	 }
         /*
         else if(index == 5){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt6.search(search[x]);
      		}
	 }*/
      //output end time

      //output number of swaps
      cout << "SWAPS for Search Phase: "<< swaps << endl;
      //output number of comparisons
      cout << "COMPARISONS for Insertion Phase: "<<comparisons << endl <<endl;

    //initialize swaps and comparisons
    swaps=0;
    comparisons=0;

    //DELETION PHASE
        //adt1
         if(index == 0){
      		//output start time
      		//cout << clock() << endl;
 		for(y =0; y<k;y++){
		//search
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt1.find(deleteList[x]);
      		}
		//delete
      		tempNum = adt1.remove();
		}

	 }
         //adt2
         else if(index == 1){
      		//output start time
      		//cout << clock() << endl;
 		for(y =0; y<k;y++){
		//search
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt2.find(deleteList[x]);
      		}
		//delete
      		adt2.remove();
		}
	 }
         //adt3
         else if(index == 2){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<k;x++){
      		adt3.iDeleteItem(deleteList[x]);
      		}
	 }
         //adt4
         else if(index == 3){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<k;x++){
      		adt4.DeleteItem(deleteList[x]);
      		}
	 }
         else if(index == 4){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<k;x++){
      		adt5.deleteInt(deleteList[x]);
      		}
	 }
         /*
         else if(index == 5){
      		//output start time
      		//cout << clock() << endl;
		//insert
      		for(x =0; x<MAX_INTEGERS;x++){
      		adt6.search(search[x]);
      		}
	 }*/
      //output end time

      //output number of swaps
      cout << "SWAPS for Deletion Phase: "<< swaps << endl;
      //output number of comparisons
      cout << "COMPARISONS for Insertion Phase: "<<comparisons << endl<<endl;

  }//end of for loop
  //end 
  return 0;
}

