//Class written by 
using namespace std;
struct nodeSort
   {
    int value;
    nodeSort* next;
   };

class linkedListSorted{
   public:
  linkedListSorted();
  linkedListSorted(const linkedListSorted&);
  ~linkedListSorted();
  bool goToBeginning();
  bool goToEnd();
  bool find(int);
  bool goToPrior();
  bool insert(int);
  void remove(int);
  bool replace(int);
  int getCursor();
  bool empty();
  bool full();
  void clear();
  void print();
  private:
  bool insertAfter(int);
  bool insertBefore(int);
  nodeSort* head;
  nodeSort* cursor;
};
